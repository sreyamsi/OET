// Call backend API
fetch("/api/students")
    .then(response => response.json())
    .then(data => {
        let list = document.getElementById("students");
        data.forEach(student => {
            let li = document.createElement("li");
            li.innerText = student.name;
            list.appendChild(li);
        });
    })
    .catch(err => console.error("Error fetching students:", err));
