package com.example.outreach_education_tracker.entity;

public enum RequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}
