package com.example.outreach_education_tracker.mapper;

import com.example.outreach_education_tracker.dto.GoalDto;
import com.example.outreach_education_tracker.dto.TaskDto;
import com.example.outreach_education_tracker.dto.UserDto;
import com.example.outreach_education_tracker.entity.Goal;
import com.example.outreach_education_tracker.entity.Task;
import com.example.outreach_education_tracker.entity.User;

public class EntityToDtoMapper {

    public static GoalDto toGoalDto(Goal goal) {
        return new GoalDto(
                goal.getGoalId(),
                goal.getTitle(),
                goal.getDescription(),
                goal.getDueDate(),
                goal.getProgressPercentage(),
                goal.getStatus().name(),
                goal.getPriority().name(),
                goal.getStudent().getUserId(),
                goal.getCreator().getUserId()
        );
    }

    public static TaskDto toTaskDto(Task task) {
        return new TaskDto(
                task.getTaskId(),
                task.getTitle(),
                task.getDescription(),
                task.getDueDate(),
                task.getProgressPercentage(),
                task.getStatus(),
                task.getMentor().getUserId(),
                task.getStudent().getUserId()
        );
    }

    public static UserDto toUserDto(User user) {
        return new UserDto(
                user.getUserId(),
                user.getName(),
                user.getEmail(),
                user.getRole()
        );
    }
}
