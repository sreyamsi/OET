package com.example.outreach_education_tracker.mapper;

import com.example.outreach_education_tracker.dto.UserDto;
import com.example.outreach_education_tracker.entity.User;
import org.springframework.stereotype.Component;

@Component // Marks this as a Spring Bean, making it injectable
public class UserMapper {

    public UserDto toUserDto(User user) {
        if (user == null) {
            return null;
        }
        UserDto dto = new UserDto();
        dto.setUserId(user.getUserId());
        dto.setName(user.getName());
        dto.setEmail(user.getEmail());
        dto.setRole(user.getRole());
        return dto;
    }
}