package com.example.outreach_education_tracker.entity;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}
