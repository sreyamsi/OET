package com.example.outreach_education_tracker.repository;

import com.example.outreach_education_tracker.entity.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<Task, Integer> {
    List<Task> findByStudent_UserId(Integer studentId);
    List<Task> findByMentor_UserId(Integer mentorId);

    List<Task> findByStudent_UserIdAndCreatedAtBetween(
            Integer studentId,
            LocalDate startDate,
            LocalDate endDate
    );
}
