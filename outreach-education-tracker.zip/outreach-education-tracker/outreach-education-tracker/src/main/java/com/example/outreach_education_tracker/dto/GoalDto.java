package com.example.outreach_education_tracker.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GoalDto {
    private Integer goalId;
    private String title;
    private String description;
    private LocalDate dueDate;
    private Integer progressPercentage;  // ✅ new column
    private String status;
    private String priority;
    private Integer studentId;
    private Integer creatorId;
}
