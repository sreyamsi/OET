package com.example.outreach_education_tracker.controller;

import com.example.outreach_education_tracker.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/student/{studentId}")
    public ResponseEntity<Map<String, Object>> getWeeklyReport(
            @PathVariable Integer studentId,
            @RequestParam String weekStart,
            @RequestParam String weekEnd) {

        LocalDate start = LocalDate.parse(weekStart);
        LocalDate end = LocalDate.parse(weekEnd);

        return ResponseEntity.ok(reportService.generateWeeklyReport(studentId, start, end));
    }
}
