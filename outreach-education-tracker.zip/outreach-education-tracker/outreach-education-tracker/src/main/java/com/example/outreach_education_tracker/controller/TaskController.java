package com.example.outreach_education_tracker.controller;

import com.example.outreach_education_tracker.dto.TaskDto;
import com.example.outreach_education_tracker.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    @Autowired
    private TaskService taskService;

    // Mentor assigns task to student
    @PostMapping("/mentor/{mentorId}/student/{studentId}")
    public ResponseEntity<TaskDto> createTask(
            @PathVariable Integer mentorId,
            @PathVariable Integer studentId,
            @RequestBody TaskDto dto) {
        return ResponseEntity.ok(taskService.createTask(mentorId, studentId, dto));
    }

    // Get tasks for a student
    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<TaskDto>> getTasksForStudent(@PathVariable Integer studentId) {
        return ResponseEntity.ok(taskService.getTasksForStudent(studentId));
    }

    // Get tasks for a mentor
    @GetMapping("/mentor/{mentorId}")
    public ResponseEntity<List<TaskDto>> getTasksForMentor(@PathVariable Integer mentorId) {
        return ResponseEntity.ok(taskService.getTasksForMentor(mentorId));
    }


    // Student updates task status
    @PutMapping("/{taskId}/status")
    public ResponseEntity<TaskDto> updateTaskStatus(
            @PathVariable Integer taskId,
            @RequestParam("status") String status) {
        return ResponseEntity.ok(taskService.updateTaskStatus(taskId, status));
    }

}
