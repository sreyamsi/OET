package com.example.outreach_education_tracker.controller;

import com.example.outreach_education_tracker.dto.GoalDto;
import com.example.outreach_education_tracker.service.GoalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/goals")
public class GoalController {

    @Autowired
    private GoalService goalService;

    @PostMapping
    public ResponseEntity<GoalDto> createGoal(@RequestBody GoalDto dto) {
        return ResponseEntity.ok(goalService.createGoal(dto));
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<GoalDto>> getGoalsForStudent(@PathVariable Integer studentId) {
        return ResponseEntity.ok(goalService.getGoalsForStudent(studentId));
    }

    // ✅ Separate endpoint to update progress
    @PutMapping("/{goalId}/progress")
    public ResponseEntity<GoalDto> updateProgress(
            @PathVariable Integer goalId,
            @RequestParam Integer progressPercentage) {

        return ResponseEntity.ok(goalService.updateGoalProgress(goalId, progressPercentage));
    }

    // ✅ Separate endpoint to update status
    @PutMapping("/{goalId}/status")
    public ResponseEntity<GoalDto> updateStatus(
            @PathVariable Integer goalId,
            @RequestParam String status) {

        return ResponseEntity.ok(goalService.updateGoalStatus(goalId, status));
    }
}
