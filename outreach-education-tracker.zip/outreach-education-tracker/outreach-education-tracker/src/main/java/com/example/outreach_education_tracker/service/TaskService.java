package com.example.outreach_education_tracker.service;

import com.example.outreach_education_tracker.dto.TaskDto;
import com.example.outreach_education_tracker.entity.Task;
import com.example.outreach_education_tracker.entity.TaskStatus;
import com.example.outreach_education_tracker.entity.User;
import com.example.outreach_education_tracker.repository.TaskRepository;
import com.example.outreach_education_tracker.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TaskService {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private UserRepository userRepository;

    // ✅ create task
    public TaskDto createTask(Integer mentorId, Integer studentId, TaskDto dto) {
        User mentor = userRepository.findById(mentorId)
                .orElseThrow(() -> new EntityNotFoundException("Mentor not found"));

        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new EntityNotFoundException("Student not found"));

        Task task = new Task();
        task.setTitle(dto.getTitle());
        task.setDescription(dto.getDescription());
        task.setDueDate(dto.getDueDate());
        task.setStatus(TaskStatus.TO_DO);
        task.setMentor(mentor);
        task.setStudent(student);
        task.setProgressPercentage(0); // default when created

        Task saved = taskRepository.save(task);

        return toDto(saved);
    }

    // ✅ get tasks for student
    public List<TaskDto> getTasksForStudent(Integer studentId) {
        return taskRepository.findByStudent_UserId(studentId)
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    // ✅ get tasks for mentor
    public List<TaskDto> getTasksForMentor(Integer mentorId) {
        return taskRepository.findByMentor_UserId(mentorId)
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    // ✅ update task status only
    public TaskDto updateTaskStatus(Integer taskId, String status) {
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new EntityNotFoundException("Task not found"));

        TaskStatus newStatus;
        try {
            newStatus = TaskStatus.valueOf(status.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Invalid status. Allowed: TO_DO, IN_PROGRESS, COMPLETED");
        }

        task.setStatus(newStatus);
        Task updated = taskRepository.save(task);

        return toDto(updated);
    }

    // ✅ NEW FUNCTION: update progress percentage
    public TaskDto updateTaskProgress(Integer taskId, Integer progress) {
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new EntityNotFoundException("Task not found"));

        // set progress
        task.setProgressPercentage(progress);

        // auto-update status based on percentage
        if (progress == 100) {
            task.setStatus(TaskStatus.COMPLETED);
        } else if (progress > 0) {
            task.setStatus(TaskStatus.IN_PROGRESS);
        } else {
            task.setStatus(TaskStatus.TO_DO);
        }

        Task updated = taskRepository.save(task);

        return toDto(updated);
    }

    // ✅ helper convert entity -> dto
    private TaskDto toDto(Task task) {
    return new TaskDto(
            task.getTaskId(),
            task.getTitle(),
            task.getDescription(),
            task.getDueDate(),
            task.getProgressPercentage(),        
            task.getStatus(),
            task.getMentor().getUserId(),
            task.getStudent().getUserId()
        );
    }


}
