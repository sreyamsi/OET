package com.example.outreach_education_tracker.service;

import com.example.outreach_education_tracker.dto.TaskDto;
import com.example.outreach_education_tracker.entity.Task;
import com.example.outreach_education_tracker.entity.TaskStatus;
import com.example.outreach_education_tracker.entity.User;
import com.example.outreach_education_tracker.repository.TaskRepository;
import com.example.outreach_education_tracker.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TaskService {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private UserRepository userRepository;

    public TaskDto createTask(Integer mentorId, Integer studentId, TaskDto dto) {
        User mentor = userRepository.findById(mentorId)
                .orElseThrow(() -> new EntityNotFoundException("Mentor not found"));

        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new EntityNotFoundException("Student not found"));

        Task task = new Task();
        task.setTitle(dto.getTitle());
        task.setDescription(dto.getDescription());
        task.setDueDate(dto.getDueDate());
        task.setStatus(TaskStatus.TO_DO);
        task.setMentor(mentor);
        task.setStudent(student);

        Task saved = taskRepository.save(task);

        return new TaskDto(saved.getTaskId(), saved.getTitle(), saved.getDescription(),
                saved.getDueDate(), saved.getStatus(), mentorId, studentId);
    }

    public List<TaskDto> getTasksForStudent(Integer studentId) {
        return taskRepository.findByStudent_UserId(studentId)
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public List<TaskDto> getTasksForMentor(Integer mentorId) {
        return taskRepository.findByMentor_UserId(mentorId)
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    private TaskDto toDto(Task task) {
        return new TaskDto(task.getTaskId(), task.getTitle(), task.getDescription(),
                task.getDueDate(), task.getStatus(),
                task.getMentor().getUserId(), task.getStudent().getUserId());
    }


    public TaskDto updateTaskStatus(Integer taskId, String status) {
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new EntityNotFoundException("Task not found"));

        TaskStatus newStatus;
        try {
            newStatus = TaskStatus.valueOf(status.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Invalid status. Allowed: TO_DO, IN_PROGRESS, COMPLETED");
        }

        task.setStatus(newStatus);
        Task updated = taskRepository.save(task);

        return toDto(updated);
    }

}
