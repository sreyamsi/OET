package com.example.outreach_education_tracker.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WeeklyReportDto {
    private LocalDate weekStart;
    private LocalDate weekEnd;
    private List<TaskDto> tasks;
    private List<GoalDto> goals;
}
