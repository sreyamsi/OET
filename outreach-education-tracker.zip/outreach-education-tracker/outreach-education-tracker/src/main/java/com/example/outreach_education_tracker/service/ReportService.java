package com.example.outreach_education_tracker.service;

import com.example.outreach_education_tracker.dto.GoalDto;
import com.example.outreach_education_tracker.dto.TaskDto;
import com.example.outreach_education_tracker.dto.UserDto;
import com.example.outreach_education_tracker.entity.User;
import com.example.outreach_education_tracker.mapper.EntityToDtoMapper;
import com.example.outreach_education_tracker.repository.GoalRepository;
import com.example.outreach_education_tracker.repository.TaskRepository;
import com.example.outreach_education_tracker.repository.UserRepository;
import com.example.outreach_education_tracker.repository.MentorStudentMappingRepository;
import com.example.outreach_education_tracker.entity.RequestStatus;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;


@Service
public class ReportService {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private GoalRepository goalRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MentorStudentMappingRepository mappingRepository;

    // ✅ Student weekly report
    public Map<String, Object> generateWeeklyReport(Integer studentId, LocalDate weekStart, LocalDate weekEnd) {
        Map<String, Object> report = new HashMap<>();

        List<TaskDto> tasks = taskRepository
                .findByStudent_UserIdAndCreatedAtBetween(studentId, weekStart, weekEnd)
                .stream()
                .map(EntityToDtoMapper::toTaskDto)
                .collect(Collectors.toList());

        List<GoalDto> goals = goalRepository
                .findByStudent_UserIdAndCreatedAtBetween(studentId, weekStart, weekEnd)
                .stream()
                .map(EntityToDtoMapper::toGoalDto)
                .collect(Collectors.toList());

        report.put("studentId", studentId);
        report.put("weekStart", weekStart);
        report.put("weekEnd", weekEnd);
        report.put("tasks", tasks);
        report.put("goals", goals);

        return report;
    }

    // ✅ Student full report from registration
    public List<Map<String, Object>> generateReportsFromRegistration(Integer studentId) {
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new EntityNotFoundException("Student not found"));

        LocalDate registrationDate = student.getRegistrationDate();
        LocalDate today = LocalDate.now();

        List<Map<String, Object>> allReports = new ArrayList<>();

        LocalDate weekStart = registrationDate;
        while (!weekStart.isAfter(today)) {
            LocalDate weekEnd = weekStart.with(DayOfWeek.SATURDAY);
            if (weekEnd.isAfter(today)) weekEnd = today;

            allReports.add(generateWeeklyReport(studentId, weekStart, weekEnd));
            weekStart = weekEnd.plusDays(1);
        }

        return allReports;
    }

    // ✅ Mentor: get all approved mentees
    public List<UserDto> getMenteesForMentor(Integer mentorId) {
        userRepository.findById(mentorId)
                .filter(user -> user.getRole().toString().equals("MENTOR"))
                .orElseThrow(() -> new EntityNotFoundException("Mentor not found"));

        return mappingRepository.findByMentor_UserIdAndStatus(mentorId, RequestStatus.APPROVED)
                .stream()
                .map(mapping -> mapping.getStudent())
                .map(EntityToDtoMapper::toUserDto)
                .collect(Collectors.toList());
    }

    // ✅ Mentor: get weekly reports for a specific student
    public List<Map<String, Object>> getStudentReportForMentor(Integer mentorId, Integer studentId) {
        boolean isMentee = mappingRepository.findByMentor_UserIdAndStatus(mentorId, RequestStatus.APPROVED)
                .stream()
                .anyMatch(mapping -> mapping.getStudent().getUserId().equals(studentId));

        if (!isMentee) {
            throw new EntityNotFoundException("This student is not a mentee of this mentor");
        }

        return generateReportsFromRegistration(studentId);
    }

    // Get all reports of all approved mentees for a mentor
    public Map<Integer, List<Map<String, Object>>> getAllMenteesReports(Integer mentorId) {
        // 1️⃣ Get all approved mentees
        List<UserDto> mentees = getMenteesForMentor(mentorId);

        // 2️⃣ Map each studentId to their full report
        Map<Integer, List<Map<String, Object>>> allReports = new HashMap<>();
        for (UserDto student : mentees) {
            allReports.put(student.getUserId(), generateReportsFromRegistration(student.getUserId()));
        }

        return allReports;
    }

}
