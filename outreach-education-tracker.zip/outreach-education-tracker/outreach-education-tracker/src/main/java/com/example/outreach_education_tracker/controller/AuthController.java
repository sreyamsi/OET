package com.example.outreach_education_tracker.controller;

import com.example.outreach_education_tracker.dto.LoginRequestDto;
import com.example.outreach_education_tracker.dto.UserDto; // This import is now explicitly used
import com.example.outreach_education_tracker.mapper.UserMapper;
import com.example.outreach_education_tracker.entity.User;
import com.example.outreach_education_tracker.service.UserService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserMapper userMapper;

    @PostMapping("/register")
    // FIX: Changed ResponseEntity<?> to ResponseEntity<UserDto>
    public ResponseEntity<UserDto> registerUser(@RequestBody User user) {
        try {
            User registeredUser = userService.registerUser(user);
            UserDto userDto = userMapper.toUserDto(registeredUser);
            return ResponseEntity.status(201).body(userDto);
        } catch (IllegalStateException e) {
            // It's good practice to return a specific error response, not the DTO
            // but for simplicity, we'll return null or handle it as before.
            // For a real app, you'd have an ErrorDto.
            return ResponseEntity.badRequest().body(null); 
        }
    }

    @PostMapping("/login")
    // FIX: Changed ResponseEntity<?> to ResponseEntity<UserDto>
    public ResponseEntity<UserDto> loginUser(@RequestBody LoginRequestDto loginRequest) {
        try {
            User user = userService.login(loginRequest.getEmail(), loginRequest.getPassword());
            UserDto userDto = userMapper.toUserDto(user);
            return ResponseEntity.ok(userDto);
        } catch (EntityNotFoundException | IllegalArgumentException e) {
            return ResponseEntity.status(401).body(null);
        }
    }
}