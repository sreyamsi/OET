package com.example.outreach_education_tracker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.outreach_education_tracker.dto.MentorStudentMappingDto;
import com.example.outreach_education_tracker.entity.MentorStudentMapping;
import com.example.outreach_education_tracker.entity.RequestStatus;
import com.example.outreach_education_tracker.mapper.UserMapper;
import com.example.outreach_education_tracker.repository.MentorStudentMappingRepository;

import jakarta.persistence.EntityNotFoundException;

import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private MentorStudentMappingRepository mappingRepository;

    @Autowired
    private UserMapper userMapper;

    @GetMapping("/requests")
    public ResponseEntity<List<MentorStudentMappingDto>> getPendingRequests() {
        List<MentorStudentMapping> pending = mappingRepository.findByStatus(RequestStatus.PENDING);
        List<MentorStudentMappingDto> dtos = pending.stream()
            .map(m -> new MentorStudentMappingDto(
                m.getMappingId(),
                userMapper.toUserDto(m.getMentor()),
                userMapper.toUserDto(m.getStudent()),
                m.getStatus()
            ))
            .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }


    @PostMapping("/requests/{id}/approve")
    public ResponseEntity<?> approveRequest(@PathVariable Integer id) {
        MentorStudentMapping mapping = mappingRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Request not found"));
        mapping.setStatus(RequestStatus.APPROVED);
        mappingRepository.save(mapping);
        return ResponseEntity.ok("Request approved");
    }

    @PostMapping("/requests/{id}/reject")
    public ResponseEntity<?> rejectRequest(@PathVariable Integer id) {
        MentorStudentMapping mapping = mappingRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Request not found"));
        mapping.setStatus(RequestStatus.REJECTED);
        mappingRepository.save(mapping);
        return ResponseEntity.ok("Request rejected");
    }
}
