package com.example.outreach_education_tracker.entity;

public enum TaskStatus {
    TO_DO,
    IN_PROGRESS,
    COMPLETED
}
