package com.example.outreach_education_tracker.controller;

import com.example.outreach_education_tracker.dto.UserDto;
import com.example.outreach_education_tracker.service.MentorService;
import com.example.outreach_education_tracker.service.ReportService;

import jakarta.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;


import java.util.List;

@RestController
@RequestMapping("/api/mentors")
public class MentorController {

    @Autowired
    private MentorService mentorService;

    @Autowired
    private ReportService reportService;

    // ✅ List all assigned students (mentees)
    @GetMapping("/{mentorId}/students")
    public ResponseEntity<?> getAssignedStudentsForMentor(@PathVariable Integer mentorId) {
        try {
            List<UserDto> students = reportService.getMenteesForMentor(mentorId);
            return ResponseEntity.ok(students);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    // ✅ Generate a student report for mentor
    @GetMapping("/{mentorId}/students/{studentId}/report")
    public ResponseEntity<?> getStudentReportForMentor(
            @PathVariable Integer mentorId,
            @PathVariable Integer studentId) {
        try {
            List<Map<String, Object>> report = reportService.getStudentReportForMentor(mentorId, studentId);
            return ResponseEntity.ok(report);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    // Optional: assign student to mentor
    @PostMapping("/{mentorId}/students/{studentId}")
    public ResponseEntity<?> assignMentor(@PathVariable Integer mentorId, @PathVariable Integer studentId) {
        try {
            mentorService.assignMentorToStudent(mentorId, studentId);
            return ResponseEntity.status(201).body("Student successfully assigned to mentor.");
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    // GET all mentees reports
    @GetMapping("/{mentorId}/students/reports")
    public ResponseEntity<?> getAllMenteesReports(@PathVariable Integer mentorId) {
        try {
            Map<Integer, List<Map<String, Object>>> reports = reportService.getAllMenteesReports(mentorId);
            return ResponseEntity.ok(reports);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

}
