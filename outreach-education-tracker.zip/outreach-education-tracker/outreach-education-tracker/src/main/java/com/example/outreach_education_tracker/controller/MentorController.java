package com.example.outreach_education_tracker.controller;

import com.example.outreach_education_tracker.dto.UserDto;
import com.example.outreach_education_tracker.service.MentorService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/mentors")
public class MentorController {

    @Autowired
    private MentorService mentorService;

    @GetMapping("/{mentorId}/students")
    public ResponseEntity<?> getAssignedStudentsForMentor(@PathVariable Integer mentorId) {
        try {
            List<UserDto> students = mentorService.getAssignedStudents(mentorId);
            return ResponseEntity.ok(students);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    @PostMapping("/{mentorId}/students/{studentId}")
    public ResponseEntity<?> assignMentor(@PathVariable Integer mentorId, @PathVariable Integer studentId) {
        try {
            mentorService.assignMentorToStudent(mentorId, studentId);
            return ResponseEntity.status(201).body("Student successfully assigned to mentor.");
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    
}