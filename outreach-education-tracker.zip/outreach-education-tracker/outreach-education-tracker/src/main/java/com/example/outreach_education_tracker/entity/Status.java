package com.example.outreach_education_tracker.entity;

public enum Status {
    TO_DO,
    IN_PROGRESS,
    COMPLETED
}
