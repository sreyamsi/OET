package com.example.outreach_education_tracker.repository;

import com.example.outreach_education_tracker.entity.MentorStudentMapping;
import com.example.outreach_education_tracker.entity.RequestStatus;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MentorStudentMappingRepository extends JpaRepository<MentorStudentMapping, Integer> {

    List<MentorStudentMapping> findByMentor_UserId(Integer mentorId);

    // Only approved students
    List<MentorStudentMapping> findByMentor_UserIdAndStatus(Integer mentorId, RequestStatus status);

    // For admin
    List<MentorStudentMapping> findByStatus(RequestStatus status);

    // ADD THIS NEW METHOD: Finds all mentors for a given student
    List<MentorStudentMapping> findByStudent_UserIdAndStatus(Integer studentId, RequestStatus status);
}
