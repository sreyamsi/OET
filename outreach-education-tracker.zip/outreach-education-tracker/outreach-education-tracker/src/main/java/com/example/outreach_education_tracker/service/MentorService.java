package com.example.outreach_education_tracker.service;

import com.example.outreach_education_tracker.dto.UserDto; // You will create this DTO
import com.example.outreach_education_tracker.entity.MentorStudentMapping;
import com.example.outreach_education_tracker.entity.Role;
import com.example.outreach_education_tracker.entity.RequestStatus;
import com.example.outreach_education_tracker.entity.User;
import com.example.outreach_education_tracker.repository.MentorStudentMappingRepository;
import com.example.outreach_education_tracker.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MentorService {

    @Autowired
    private MentorStudentMappingRepository mappingRepository;

    @Autowired
    private UserRepository userRepository;

     public MentorStudentMapping assignMentorToStudent(Integer mentorId, Integer studentId) {
        User mentor = userRepository.findById(mentorId)
                .filter(user -> user.getRole() == Role.MENTOR)
                .orElseThrow(() -> new EntityNotFoundException("Mentor not found"));

        User student = userRepository.findById(studentId)
                .filter(user -> user.getRole() == Role.STUDENT)
                .orElseThrow(() -> new EntityNotFoundException("Student not found"));

        MentorStudentMapping mapping = new MentorStudentMapping();
        mapping.setMentor(mentor);
        mapping.setStudent(student);
        mapping.setStatus(RequestStatus.PENDING);

        return mappingRepository.save(mapping);
    }


    public List<UserDto> getAssignedStudents(Integer mentorId) {
        userRepository.findById(mentorId)
                .filter(user -> user.getRole() == Role.MENTOR)
                .orElseThrow(() -> new EntityNotFoundException("Mentor not found"));

        List<MentorStudentMapping> mappings = mappingRepository.findByMentor_UserIdAndStatus(
                mentorId, RequestStatus.APPROVED);

        return mappings.stream()
                .map(MentorStudentMapping::getStudent)
                .map(this::convertToUserDto)
                .collect(Collectors.toList());
     }


    // Helper method to convert a User Entity to a User DTO
    private UserDto convertToUserDto(User user) {
        UserDto dto = new UserDto();
        dto.setUserId(user.getUserId());
        dto.setName(user.getName());
        dto.setEmail(user.getEmail());
        dto.setRole(user.getRole());
        return dto;
    }
}