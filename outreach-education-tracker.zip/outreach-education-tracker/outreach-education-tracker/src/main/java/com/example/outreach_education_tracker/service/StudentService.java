package com.example.outreach_education_tracker.service;
// Create this new file in your 'service' package

import com.example.outreach_education_tracker.dto.UserDto;
import com.example.outreach_education_tracker.mapper.UserMapper;
import com.example.outreach_education_tracker.entity.MentorStudentMapping;
import com.example.outreach_education_tracker.entity.RequestStatus;
import com.example.outreach_education_tracker.repository.MentorStudentMappingRepository;
import com.example.outreach_education_tracker.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class StudentService {

    @Autowired
    private MentorStudentMappingRepository mappingRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserMapper userMapper;

    public List<UserDto> getAssignedMentors(Integer studentId) {
        // 1. Validate that the student exists
        userRepository.findById(studentId)
                .filter(user -> user.getRole() == com.example.outreach_education_tracker.entity.Role.STUDENT)
                .orElseThrow(() -> new EntityNotFoundException("Student not found with ID: " + studentId));

        // 2. Use the repository to find all mappings for this student
        //List<MentorStudentMapping> mappings = mappingRepository.findByStudent_UserId(studentId);
        List<MentorStudentMapping> mappings = mappingRepository.findByStudent_UserIdAndStatus(
                studentId, RequestStatus.APPROVED);

        // 3. Extract the mentor from each mapping and convert to a DTO
        return mappings.stream()
                .map(MentorStudentMapping::getMentor)
                .map(userMapper::toUserDto)
                .collect(Collectors.toList());
    }
}