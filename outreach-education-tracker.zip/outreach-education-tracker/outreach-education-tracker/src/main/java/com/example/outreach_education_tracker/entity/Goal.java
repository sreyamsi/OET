package com.example.outreach_education_tracker.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "goals")
public class Goal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer goalId;

    @Column(nullable = false)
    private String title;

    @Lob // For longer text descriptions
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.TO_DO; // Default value

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Priority priority = Priority.MEDIUM; // Default value

    private LocalDate dueDate;

    private boolean isMentorAssigned = false;

    // --- Relationships ---

    // The student this goal is assigned to. Many goals can belong to one user.
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private User student;

    // The user (mentor or student) who created this goal.
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by", nullable = false)
    private User creator;
}

// You can create these enums in their own files or here for simplicity
enum Status {
    TO_DO,
    IN_PROGRESS,
    COMPLETED
}

enum Priority {
    LOW,
    MEDIUM,
    HIGH
}
