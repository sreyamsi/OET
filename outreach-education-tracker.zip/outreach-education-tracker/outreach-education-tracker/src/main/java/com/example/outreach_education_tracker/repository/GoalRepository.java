package com.example.outreach_education_tracker.repository;


import com.example.outreach_education_tracker.entity.Goal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface GoalRepository extends JpaRepository<Goal, Integer> {
    
    // Example of a custom query to find all goals for a specific student
    List<Goal> findByStudent_UserId(Integer studentId);

    List<Goal> findByStudent_UserIdAndCreatedAtBetween(
            Integer studentId,
            LocalDate startDate,
            LocalDate endDate
    );
} 
