    package com.example.outreach_education_tracker.dto;

    import com.example.outreach_education_tracker.entity.RequestStatus;

    import lombok.AllArgsConstructor;
    import lombok.Data;
    import lombok.NoArgsConstructor;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public class MentorStudentMappingDto {
        private Integer mappingId;
        private UserDto mentor;
        private UserDto student;
        private RequestStatus status;
    }
