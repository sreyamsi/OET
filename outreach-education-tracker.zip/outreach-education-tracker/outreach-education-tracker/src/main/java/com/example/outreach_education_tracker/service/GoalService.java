package com.example.outreach_education_tracker.service;

import com.example.outreach_education_tracker.dto.GoalDto;
import com.example.outreach_education_tracker.entity.Goal;
import com.example.outreach_education_tracker.entity.Priority;
import com.example.outreach_education_tracker.entity.Status;
import com.example.outreach_education_tracker.entity.User;
import com.example.outreach_education_tracker.repository.GoalRepository;
import com.example.outreach_education_tracker.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class GoalService {

    @Autowired
    private GoalRepository goalRepository;

    @Autowired
    private UserRepository userRepository;

    // Create goal
    public GoalDto createGoal(GoalDto dto) {
        User student = userRepository.findById(dto.getStudentId())
                .orElseThrow(() -> new EntityNotFoundException("Student not found"));
        User creator = userRepository.findById(dto.getCreatorId())
                .orElseThrow(() -> new EntityNotFoundException("Creator not found"));

        Goal goal = new Goal();
        goal.setTitle(dto.getTitle());
        goal.setDescription(dto.getDescription());
        goal.setDueDate(dto.getDueDate());
        goal.setProgressPercentage(dto.getProgressPercentage() != null ? dto.getProgressPercentage() : 0);
        goal.setStatus(Status.valueOf(dto.getStatus().toUpperCase()));
        goal.setPriority(Priority.valueOf(dto.getPriority().toUpperCase()));
        goal.setStudent(student);
        goal.setCreator(creator);

        return toDto(goalRepository.save(goal));
    }

    // Get goals for student
    public List<GoalDto> getGoalsForStudent(Integer studentId) {
        return goalRepository.findByStudent_UserId(studentId)
                .stream().map(this::toDto).collect(Collectors.toList());
    }

    // Update only progress
    public GoalDto updateGoalProgress(Integer goalId, Integer progressPercentage) {
        Goal goal = goalRepository.findById(goalId)
                .orElseThrow(() -> new EntityNotFoundException("Goal not found"));

        goal.setProgressPercentage(progressPercentage);
        return toDto(goalRepository.save(goal));
    }

    // Update only status
    public GoalDto updateGoalStatus(Integer goalId, String status) {
        Goal goal = goalRepository.findById(goalId)
                .orElseThrow(() -> new EntityNotFoundException("Goal not found"));

        goal.setStatus(Status.valueOf(status.toUpperCase()));
        return toDto(goalRepository.save(goal));
    }

    private GoalDto toDto(Goal goal) {
        return new GoalDto(
                goal.getGoalId(),
                goal.getTitle(),
                goal.getDescription(),
                goal.getDueDate(),
                goal.getProgressPercentage(),
                goal.getStatus().name(),
                goal.getPriority().name(),
                goal.getStudent().getUserId(),
                goal.getCreator().getUserId()
        );
    }
}
