package com.example.outreach_education_tracker.controller;

// Create this new file in your 'controller' package

import com.example.outreach_education_tracker.dto.UserDto;
import com.example.outreach_education_tracker.service.ReportService;
import com.example.outreach_education_tracker.service.StudentService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @Autowired
    private ReportService reportService;

    /**
     * Gets the list of all mentors assigned to a specific student.
     * URL: GET /api/students/1/mentors
     */
    @GetMapping("/{studentId}/mentors")
    public ResponseEntity<?> getAssignedMentorsForStudent(@PathVariable Integer studentId) {
        try {
            List<UserDto> mentors = studentService.getAssignedMentors(studentId);
            return ResponseEntity.ok(mentors);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    @GetMapping("/{studentId}/reports")
public ResponseEntity<?> getStudentReports(@PathVariable Integer studentId) {
    return ResponseEntity.ok(reportService.generateReportsFromRegistration(studentId));
}

}