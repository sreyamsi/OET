package com.example.outreach_education_tracker.entity;

public enum Role {
    STUDENT,
    MENTOR,
    ADMIN
}
