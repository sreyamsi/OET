package com.example.outreach_education_tracker.dto;

import com.example.outreach_education_tracker.entity.TaskStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaskDto {
    private Integer taskId;
    private String title;
    private String description;
    private LocalDate dueDate;
    private TaskStatus status;
    private Integer mentorId;
    private Integer studentId;
}
