package com.example.outreach_education_tracker.dto;

import lombok.Data;

@Data
public class LoginRequestDto {
    private String email;
    private String password;
}