package com.example.outreach_education_tracker.dto;

import com.example.outreach_education_tracker.entity.Role;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * UserDto (Data Transfer Object) is used to transfer user data between the
 * service and the controller (API layer). It ensures that sensitive information
 * like the password is not exposed to the outside world.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {

    private Integer userId;
    private String name;
    private String email;
    private Role role;

}