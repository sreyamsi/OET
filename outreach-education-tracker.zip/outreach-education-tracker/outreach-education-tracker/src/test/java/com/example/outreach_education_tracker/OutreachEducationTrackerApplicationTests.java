package com.example.outreach_education_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OutreachEducationTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
