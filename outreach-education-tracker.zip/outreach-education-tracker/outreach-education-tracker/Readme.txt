1️⃣ Register Users (Optional)

POST /api/auth/register

Body (JSON):

{
  "name": "John Mentor",
  "email": "john.mentor@example.com",
  "password": "mentor123",
  "role": "MENTOR"
}


Similarly, register students:

{
  "name": "Alice Student",
  "email": "alice.student@example.com",
  "password": "student123",
  "role": "STUDENT"
}


(Optional) Register an admin:

{
  "name": "Admin User",
  "email": "admin@example.com",
  "password": "admin123",
  "role": "ADMIN"
}


Response: 201 Created with UserDto.

2️⃣ Login Users (Optional)

POST /api/auth/login

Body (JSON):

{
  "email": "john.mentor@example.com",
  "password": "mentor123"
}


Response: UserDto of logged-in user.

3️⃣ Assign Mentor to Student (Creates a Request)

POST /api/mentors/{mentorId}/students/{studentId}

Replace {mentorId} and {studentId} with IDs from your users table.

Example:

POST http://localhost:8080/api/mentors/1/students/2


Response: "Student successfully assigned to mentor."
Status in mentor_student_mapping → PENDING.

4️⃣ View Pending Requests (Admin)

GET /api/admin/requests

Returns all PENDING mentor-student requests.

Example Response:

[
  {
    "mappingId": 2,
    "mentor": { "userId": 1, "name": "John Mentor", "email": "john.mentor@example.com", "role": "MENTOR" },
    "student": { "userId": 2, "name": "Alice Student", "email": "alice.student@example.com", "role": "STUDENT" },
    "status": "PENDING"
  }
]

5️⃣ Approve a Request (Admin)

POST /api/admin/requests/{mappingId}/approve

{mappingId} → from mentor_student_mapping table or the GET response above.

Example:

POST http://localhost:8080/api/admin/requests/2/approve


Response: "Request approved"
Status in DB → APPROVED.

6️⃣ Reject a Request (Admin)

POST /api/admin/requests/{mappingId}/reject

Example:

POST http://localhost:8080/api/admin/requests/2/reject


Response: "Request rejected"
Status in DB → REJECTED.

7️⃣ View Assigned Students for a Mentor

GET /api/mentors/{mentorId}/students

Example:

GET http://localhost:8080/api/mentors/1/students


Response: List of students whose requests are APPROVED.
Only approved students appear here.

8️⃣ Optional: View All Users

GET /api/users

Returns all users (mentors, students, admins).

GET /api/users/{id}

Returns a single user by ID.




✅ Notes / Tips

IDs come from the database:

users.userId → for mentor/student IDs.

mentor_student_mapping.mappingId → for admin approval/rejection.

Workflow for testing:

Register mentor and student (or use existing entries).

Mentor assigns a student → PENDING in DB.

Admin checks /api/admin/requests.

Admin approves → status becomes APPROVED.

Mentor GET /api/mentors/{mentorId}/students → student appears.

DB Check (optional):

SELECT * FROM users;
SELECT * FROM mentor_student_mapping;
SELECT * FROM goals;


You don’t need to delete existing tables unless you want a clean start. Just be aware of existing mappings when testing.







Tasks - Task (Entity), TaskStatus (Entity), TaskRepository, TaskDto, TaskService, TaskController