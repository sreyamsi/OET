Postman API Collection for Outreach Education Tracker


Auth / User APIs:

1. Create User (Student / Mentor / Admin)
POST http://localhost:8080/api/auth/register
Body (JSON):
{
  "name": "John Mentor",
  "email": "john.mentor@example.com",
  "password": "password123",
  "role": "MENTOR"
}


(roles: STUDENT, MENTOR, ADMIN)

2. Get All Users
GET http://localhost:8080/api/users

Mentor APIs:

3. Assign Mentor to Student
POST http://localhost:8080/api/mentors/{mentorId}/students/{studentId}

4. Get Students Assigned to Mentor
GET http://localhost:8080/api/mentors/{mentorId}/students

Student APIs:

5. Get Mentors Assigned to Student
GET http://localhost:8080/api/students/{studentId}/mentors

Admin APIs:

6. Get All Pending Requests
GET http://localhost:8080/api/admin/requests

7. Approve Mentor-Student Request
POST http://localhost:8080/api/admin/requests/{mappingId}/approve

8. Reject Mentor-Student Request
POST http://localhost:8080/api/admin/requests/{mappingId}/reject

Task APIs:

9. Create Task (Mentor → Student)
POST http://localhost:8080/api/tasks/mentors/{mentorId}/students/{studentId}
Body (JSON):
{
  "title": "Complete Chapter 1",
  "description": "Read and solve problems",
  "dueDate": "2025-09-25",
  "progressPercentage": 0
}

10. Get Tasks for a Student
GET http://localhost:8080/api/tasks/student/{studentId}

11. Get Tasks Created by a Mentor
GET http://localhost:8080/api/tasks/mentor/{mentorId}

12. Update Task Status / Progress
PUT http://localhost:8080/api/tasks/{taskId}?progressPercentage=50&status=IN_PROGRESS

Goal APIs:

13. Create Goal (Student sets goal)
POST http://localhost:8080/api/goals
Body (JSON):
{
  "title": "Prepare for Exam",
  "description": "Revise all subjects",
  "dueDate": "2025-10-05",
  "progressPercentage": 0,
  "status": "TO_DO",
  "priority": "HIGH",
  "studentId": 2,
  "creatorId": 2
}

14. Get All Goals for a Student
GET http://localhost:8080/api/goals/student/{studentId}

15. Update Goal Progress / Status (Single)
PUT http://localhost:8080/api/goals/{goalId}?progressPercentage=80&status=IN_PROGRESS

16. Update only goal status
PUT http://localhost:8080/api/goals/{goalId}/status?status=COMPLETED

17. Update only goal progress
PUT http://localhost:8080/api/goals/{goalId}/progress?progressPercentage=50

18. Get weekly reports for a student
GET http://localhost:8080/api/students/2/reports

19. Get weekly reports for a specific mentee
GET http://localhost:8080/api/mentors/1/students/2/report

20. All mentees’ reports for a mentor in one API call
GET http://localhost:8080/api/mentors/1/students/reports




